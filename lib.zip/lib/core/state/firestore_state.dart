import 'package:cloud_firestore/cloud_firestore.dart';
import 'session_data_state.dart';

/// Screens consume shared session state. Firestore only feeds the state once
/// per query; its local write events and server confirmations update all views.
final firestoreState = SessionDataState();

extension StatefulQuery<T> on Query<T> {
  Stream<QuerySnapshot<T>> stateSnapshots() =>
      firestoreState.watch(('query', this), () => snapshots());
}

extension StatefulDocument<T> on DocumentReference<T> {
  Stream<DocumentSnapshot<T>> stateSnapshots() =>
      firestoreState.watch(('document', this), () => snapshots());
}
