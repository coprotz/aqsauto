import 'dart:async';

/// One retained value and one upstream subscription per key, shared by pages.
/// Idle entries expire so large projects do not stay in memory indefinitely.
class SessionDataState {
  SessionDataState({
    this.idleLifetime = const Duration(minutes: 5),
    this.maxIdleEntries = 64,
  });
  final Duration idleLifetime;
  final int maxIdleEntries;
  final Map<Object, _Feed<dynamic>> _feeds = {};

  Stream<T> watch<T>(Object key, Stream<T> Function() source) {
    return Stream<T>.multi((listener) {
      final subscription = _shared<T>(key, source).listen(
        listener.addSync,
        onError: listener.addErrorSync,
        onDone: listener.closeSync,
      );
      listener.onCancel = subscription.cancel;
      listener.onPause = subscription.pause;
      listener.onResume = subscription.resume;
    }, isBroadcast: true);
  }

  Stream<T> _shared<T>(Object key, Stream<T> Function() source) {
    final existing = _feeds[key];
    if (existing != null) return (existing as _Feed<T>).stream;
    late final _Feed<T> feed;
    feed = _Feed<T>(source, idleLifetime, () {
      if (identical(_feeds[key], feed)) _feeds.remove(key);
    });
    _feeds[key] = feed;
    final idle = _feeds.entries.where((e) => e.value.idle).toList();
    for (final entry in idle.take(
      (idle.length - maxIdleEntries).clamp(0, idle.length),
    )) {
      _feeds.remove(entry.key)?.close();
    }
    return feed.stream;
  }

  /// Call on sign-out/account changes. Never replay another account's data.
  void clear() {
    final feeds = _feeds.values.toList();
    _feeds.clear();
    for (final feed in feeds) {
      feed.close();
    }
  }
}

class _Feed<T> {
  _Feed(this.source, this.lifetime, this.onExpired) {
    stream = Stream<T>.multi((listener) {
      if (closed) {
        listener.closeSync();
        return;
      }
      timer?.cancel();
      listeners.add(listener);
      if (hasValue) listener.addSync(value as T);
      listener.onCancel = () {
        listeners.remove(listener);
        if (!closed && listeners.isEmpty)
          timer = Timer(lifetime, () {
            close();
            onExpired();
          });
      };
      subscription ??= source().listen(
        (next) {
          value = next;
          hasValue = true;
          for (final sink in listeners.toList()) {
            sink.addSync(next);
          }
        },
        onError: (Object error, StackTrace stack) {
          // Do not replay stale/possibly revoked data after an access failure.
          value = null;
          hasValue = false;
          for (final sink in listeners.toList()) {
            sink.addErrorSync(error, stack);
          }
          close();
          onExpired();
        },
        onDone: () {
          close();
          onExpired();
        },
      );
    }, isBroadcast: true);
  }
  final Stream<T> Function() source;
  final Duration lifetime;
  final void Function() onExpired;
  late final Stream<T> stream;
  final listeners = <MultiStreamController<T>>{};
  StreamSubscription<T>? subscription;
  Timer? timer;
  T? value;
  bool hasValue = false, closed = false;
  bool get idle => listeners.isEmpty;
  void close() {
    if (closed) return;
    closed = true;
    timer?.cancel();
    subscription?.cancel();
    value = null;
    for (final sink in listeners.toList()) {
      sink.closeSync();
    }
    listeners.clear();
  }
}
